// const http = require('http');
// const host = 'localhost';
// const port = 5000;

// const reqListener = function(req, res) {
//     res.end('Hello')
// };
// const server = http.createServer(reqListener);
// server.listen(port, host, ()=> {
//     console.log('Server is running')
// });


const express = require('express');
const filmsRouter =require('./routes/routes')
const genreRouter =require('./routes/genre_routes')

const app = express()
const port = 5000;

app.use(express.json())
app.use('/api', filmsRouter)
app.use('/api', genreRouter)

app.listen(port, ()=> console.log('server is running'))