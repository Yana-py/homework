const Router = require('express')
const router = new Router()
const genreController = require('../controller/genre_controller')
router.post('/genre', genreController.creatGenre)
router.get('/genre', genreController.getGenreFilms)







module.exports = router