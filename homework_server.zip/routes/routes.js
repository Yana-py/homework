const Router = require('express')
const router = new Router()
const Controller = require('../controller/controller')
router.post('/films', Controller.creatFilms)
router.get('/films', Controller.getFilms)
router.get('/films/:id', Controller.getOneFilms)
router.put('/films', Controller.updateFilms)
router.delete('/films/:id', Controller.deleteFilms)






module.exports = router