const db = require('../db')
class Controller{
    async creatFilms(req, res) {
        const {name_films, year_films} = req.body
        const newFilms =await db.query(`INSERT INTO films (name_films, year_films) values ($1, $2) RETURNING *`, [name_films, year_films]);

        res.json(newFilms.rows[0])
    }
    async getFilms(req, res) {
        const allFilms = await db.query('SELECT*FROM films')
        res.json(allFilms.rows)
    }
    async getOneFilms(req, res) {
        const id =req.params.id
        const oneFilms = await db.query('SELECT*FROM films where id = $1', [id])
        res.json(oneFilms.rows[0])
        
    }
    async updateFilms(req, res) {
        const {id, name_films, year_films} = req.body
        const newInfoFilms = await db.query('UPDATE films set name_films = $1, year_films = $2 where id = $3 RETURNING*', [name_films,year_films, id])
        res.json(newInfoFilms.rows[0])
    }
    async deleteFilms(req, res) {
        const id =req.params.id
        const delFilms = await db.query('DELETE FROM films where id = $1', [id])
        res.json(delFilms.rows[0])
    }
}

module.exports = new Controller()