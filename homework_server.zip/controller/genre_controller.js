const db = require('../db')

class genreController{
    async creatGenre(req, res) {
        const {name_genre, id_films} = req.body
        const newGenre = await db.query('INSERT INTO genre (name_genre, id_films) values ($1, $2) RETURNING * ', [name_genre, id_films])
        res.json(newGenre.rows[0])
    }
    async getGenreFilms(req, res) {
   const id = req.query.id
   const genreFilm = await db.query('SELECT* FROM genre where id_films= $1', [id])
   res.json(genreFilm.rows)
    }
}
module.exports = new genreController()